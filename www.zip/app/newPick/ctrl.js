pydmCtrl.NewPickCtrl = function ($rootScope, $scope) {


}