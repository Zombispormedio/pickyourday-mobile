pydmCtrl.CategoriasCtrl = function ($rootScope, $scope) {


}