pydmCtrl.PrepicksCtrl = function ($rootScope, $scope) {

}