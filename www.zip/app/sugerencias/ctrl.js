pydmCtrl.SugerenciasCtrl = function ($rootScope, $scope) {

}